# Jeff KPI v4.7.0

Deployable DX project with card layout, Partner filter, and fixed Apex + LWC.