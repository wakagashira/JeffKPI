import { LightningElement, track } from 'lwc';
import getUserActivitySummary from '@salesforce/apex/UserHierarchyController.getUserActivitySummary';

export default class ActivitiesKPIJeff extends LightningElement {
    @track groupedData = [];
    @track filteredData = [];
    @track errorMessage;

    @track partnerOptions = [{ label: 'All Partners', value: 'All' }];
    @track userOptions = [{ label: 'All Users', value: 'All' }];

    @track selectedPartner = 'All';
    @track selectedUser = 'All';

    connectedCallback() {
        this.loadData();
    }

    handlePartnerChange(event) {
        this.selectedPartner = event.detail.value;
        this.loadData();
    }

    handleUserChange(event) {
        this.selectedUser = event.detail.value;
        this.loadData();
    }

    loadData() {
        getUserActivitySummary()
            .then(result => {
                this.groupedData = result;
                this.filteredData = result;
                this.errorMessage = undefined;
            })
            .catch(error => {
                this.errorMessage = error.body ? error.body.message : error.message;
                this.groupedData = [];
                this.filteredData = [];
            });
    }
}
